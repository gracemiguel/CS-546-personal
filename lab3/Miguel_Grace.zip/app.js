//I pledge my honor that I've abided by the Stevens Honor System.
const people = require("./people")
const work = require("./work")

async function main(){
    try{
        const state = await people.howManyPerState('MA')
        console.log(state)
    }catch(e){
        console.log(e)
    }
    
    try{
    const peopleId = await people.getPersonById(2)
    console.log(peopleId)
    }catch(e){
        console.log(e)
    }
    try{
        const personByAge = await people.personByAge(100)
        console.log(personByAge)
    }catch(e){
        console.log(e)
    }
    try{
        const peopleMetrics = await people.peopleMetrics()
        console.log(peopleMetrics)
    }catch(e){
        console.log(e)
    }
    try{
        const fourOneOne = await work.fourOneOne('561-689-4839')
        console.log(fourOneOne)
    }catch(e){
        console.log(e)
    }
  
    try{
        const whereDoTheyWork = await work.whereDoTheyWork('108-26-6204')
        console.log(whereDoTheyWork)
    }catch(e){
        console.log(e)
    }
    try{
        const listEmployees = await work.listEmployees()
        console.log(listEmployees)
    }catch(e){
        console.log(e)
    }
   
    
    
}

main()