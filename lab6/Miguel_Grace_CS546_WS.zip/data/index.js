  
const bookData = require('./books');
const reviewsData = require('./reviews');

module.exports = {
  books: bookData,
  reviews: reviewsData
};